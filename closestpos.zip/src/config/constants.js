module.exports = {
  circunvalar: {
    name: 'circunvalar',
    lat: 4.8074954,
    lng: -75.684665
  },
  ciudadVictoria: {
    name: 'ciudad victoria',
    lat: 4.8109838,
    lng: -75.6925377
  },
  treintaDeAgosto: {
    name: '30 de agosto',
    lat: 4.8139582,
    lng: -75.7136001
  }
}